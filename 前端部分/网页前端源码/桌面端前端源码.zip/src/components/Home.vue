<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
  </div>
</template>

<script>

  export default {
    name: 'Home',
    data () {
      return {
        msg: 'This is a Vue To Exe Shell'
      }
    },
    mounted () {
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
 
</style>
